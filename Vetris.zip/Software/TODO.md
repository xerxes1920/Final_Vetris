[ ] Check when wshp(), if its possible, if not end game somehow?
[ ] Make actions mutually exclusive.
    - Else if on gameAction type

[ ] First pass implementation of the assembler.
[ ] Test assembler on Application code.